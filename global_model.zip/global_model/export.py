#! /usr/bin/env python3

"""
Exporting and Visualizing Simulation Results Module

Export and visualize simulation results from global model optimization.

This module provides functions for exporting and visualizing simulation results from global model optimization.
It includes functions for exporting phosphorylation drive S, scanning prior regularization parameters,
plotting phosphorylation drive S, generating diagnostic correlation plots, plotting residuals,
and plotting boxplots of parameters across the Pareto front.
"""

import json
import math
import os
from pathlib import Path

import numpy as np
import pandas as pd
from matplotlib import pyplot as plt, animation
import matplotlib.colors as mcolors
import seaborn as sns
from matplotlib.backends.backend_pdf import PdfPages
from pymoo.visualization.pcp import PCP
from pymoo.visualization.scatter import Scatter

from scipy.interpolate import interp1d
from scipy.stats import linregress

from global_model.config import TIME_POINTS_PROTEIN, TIME_POINTS_RNA, TIME_POINTS_PHOSPHO, MODEL, RESULTS_DIR
from global_model.params import unpack_params
from global_model.simulate import simulate_and_measure
from global_model.jacspeedup import build_S_cache_into
from config.config import setup_logger

logger = setup_logger(log_dir=RESULTS_DIR)


def build_site_meta(idx):
    """
    Returns parallel arrays of length idx.total_sites.

    Args:
    ----
    idx: Index object containing model-specific information.

    Returns
    -------
    site_protein: np.ndarray of protein names for each site
    site_psite: np.ndarray of psite labels for each site
    site_local: np.ndarray of local site indices within each protein
    """
    total = int(idx.total_sites)
    site_protein = np.empty(total, dtype=object)
    site_psite = np.empty(total, dtype=object)
    site_local = np.empty(total, dtype=np.int32)

    for i, prot in enumerate(idx.proteins):
        off = int(idx.offset_s[i])
        for j, psite in enumerate(idx.sites[i]):
            s = off + j
            site_protein[s] = prot
            site_psite[s] = psite
            site_local[s] = j

    return site_protein, site_psite, site_local


def save_pareto_3d(res, selected_solution=None, output_dir="out_moo"):
    """
    Saves a high-quality 3D Scatter plot of the Pareto Front.
    Highlights the 'selected' balanced solution if provided.

    Args:
        res: Optimization result object containing Pareto front data.
        selected_solution: Tuple of (fitness, decision variables) for the selected solution.
        output_dir: Directory where plots will be saved.
    """
    logger.info("[Output] Generating 3D Pareto Plot...")

    # 1. Setup Plot
    # Angle (elevation, azimuth) for best viewing
    plot = Scatter(
        plot_3d=True,
        angle=(45, 45),
        labels=["Prot MSE", "RNA MSE", "Phospho MSE"],
        figsize=(10, 8),
        title=("Pareto Front", {'pad': 20})
    )

    # 2. Add Data
    # All solutions in the front
    plot.add(res.F, color="grey", alpha=0.6, s=30, label="Pareto Solutions")

    # Highlight the picked solution (Red Star)
    if selected_solution is not None:
        plot.add(selected_solution, color="red", s=150, marker="*", label="Selected")

    # 3. Save
    # Pymoo plots wrap Matplotlib, so we can save easily
    save_path = os.path.join(output_dir, "pareto_front_3d.png")
    plot.save(save_path)
    logger.info(f"[Output] Saved: {save_path}")


def save_parallel_coordinates(res, selected_solution=None, output_dir="out_moo"):
    """
    Saves a Parallel Coordinate Plot (PCP).

    Args:
        res: Optimization result object containing Pareto front data.
        selected_solution: Tuple of (fitness, decision variables) for the selected solution.
        output_dir: Directory where plots will be saved.
    """
    logger.info("[Output] Generating Parallel Coordinate Plot...")

    # 1. Setup Plot
    # normalize_each_axis=True is CRITICAL because MSE errors and Reg loss
    # might have vastly different magnitudes (e.g. 1000 vs 0.1).
    plot = PCP(
        title=("Objective Trade-offs", {'pad': 20}),
        labels=["Prot MSE", "RNA MSE", "Phospho MSE"],
        normalize_each_axis=True,
        figsize=(12, 6),
        legend=(True, {'loc': "upper left"})
    )

    # 2. Styling
    plot.set_axis_style(color="grey", alpha=0.5)

    # 3. Add Data
    # Background solutions (faint)
    plot.add(res.F, color="grey", alpha=0.2, linewidth=1)

    # Highlight Selected (Bold Blue)
    if selected_solution is not None:
        plot.add(selected_solution, linewidth=4, color="blue", label="Selected")

    # 4. Save
    save_path = os.path.join(output_dir, "pareto_pcp.png")
    plot.save(save_path)
    logger.info(f"[Output] Saved: {save_path}")


def create_convergence_video(res, output_dir="out_moo", filename="optimization_history.mp4"):
    """
    Creates an animation of the Pareto Front evolution using standard Matplotlib.

    Args:
        res: Optimization result object containing Pareto front data.
        output_dir: Directory where video will be saved.
        filename: Name of the output video file.
    """
    logger.info("[Output] Rendering Optimization Video...")

    if not res.history:
        logger.info("[Warning] No history found. Cannot create video.")
        return

    # Setup Figure
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')

    # Pre-determine bounds so the camera doesn't jump around
    all_F = np.vstack([e.pop.get("F") for e in res.history])
    min_f = all_F.min(axis=0)
    max_f = all_F.max(axis=0)

    def update(frame_idx):
        ax.clear()

        # Get data for this generation
        entry = res.history[frame_idx]
        gen = entry.n_gen
        F = entry.pop.get("F")

        # Plot
        ax.scatter(F[:, 0], F[:, 1], F[:, 2], c="blue", s=10, alpha=0.6, label="Population")

        # Reference (Final Result) - Ghosted
        if res.F is not None:
            ax.scatter(res.F[:, 0], res.F[:, 1], res.F[:, 2], c="red", s=5, alpha=0.1)

        # Styling
        ax.set_title(f"Optimization History - Gen {gen}")
        ax.set_xlabel("Prot MSE")
        ax.set_ylabel("RNA MSE")
        ax.set_zlabel("Phospho MSE")
        ax.set_xlim(min_f[0], max_f[0])
        ax.set_ylim(min_f[1], max_f[1])
        ax.set_zlim(min_f[2], max_f[2])
        ax.view_init(elev=45, azim=45)

    # Create Animation
    # We skip frames to make it render faster (every 5th gen)
    frames = list(range(0, len(res.history), 5))
    if len(res.history) - 1 not in frames:
        frames.append(len(res.history) - 1)

    ani = animation.FuncAnimation(fig, update, frames=frames, interval=200)

    # Save (Try MP4 via ffmpeg, fallback to GIF via Pillow)
    save_path = os.path.join(output_dir, filename)

    try:
        # Try saving highly compressed MP4
        ani.save(save_path, writer='ffmpeg', fps=5, dpi=300)
        logger.info(f"[Output] Video saved: {save_path}")
    except Exception:
        # Fallback to GIF (universally supported, no ffmpeg needed)
        gif_path = save_path.replace(".mp4", ".gif")
        logger.info("[System] FFMPEG not found. Falling back to GIF...")
        ani.save(gif_path, writer='pillow', fps=5, dpi=300)
        logger.info(f"[Output] Video saved: {gif_path}")

    plt.close()


def export_pareto_front_to_excel(
        res,
        sys,
        idx,
        slices,
        output_path,
        weights=(1.0, 1.0, 1.0),  # (w_prot, w_rna, w_phos) used for scalar score + ranking
        top_k_trajectories=None,  # None = export trajectories for all solutions; else only top K by scalar score
        t_points_p=None,
        t_points_r=None,
        t_points_ph=None,
        rtol=1e-5,
        atol=1e-7,
        mxstep=5000,
):
    """
    Export all Pareto solutions into one Excel workbook.

    Writes sheets:
      - summary: objectives + scalar score + rank + weights
      - params_genes: per-protein parameters for each sol_id (long format)
      - params_kinases: per-kinase parameters for each sol_id (long format)
      - traj_protein: trajectories per sol_id (long format)
      - traj_rna: trajectories per sol_id (long format)
      - traj_phospho: trajectories per sol_id (long format)

    Notes:
      - This can get HUGE if you have many Pareto points. Use top_k_trajectories.
      - The function assumes res.X and res.F exist.

    Args:
        res: Optimization result object containing Pareto front data.
        sys: System object containing model-specific information.
        idx: Index object containing protein/kinase metadata.
        slices: Slices for trajectory data (e.g., time points for protein, RNA, and phospho data).
        output_path: Path to save the Excel workbook.
        weights = (w_prot, w_rna, w_phos) used for scalar score + ranking.
        top_k_trajectories: None = export trajectories for all solutions; else only top K by scalar score.
        t_points_p, t_points_r, t_points_ph: Optional time points for trajectory data.
    """
    X = np.asarray(res.X)
    F = np.asarray(res.F)

    if t_points_p is None:
        t_points_p = TIME_POINTS_PROTEIN
    if t_points_r is None:
        t_points_r = TIME_POINTS_RNA
    if t_points_ph is None:
        t_points_ph = TIME_POINTS_PHOSPHO

    w_prot, w_rna, w_phos = map(float, weights)

    # ---- Summary + ranking ----
    df_summary = pd.DataFrame(F, columns=["prot_mse", "rna_mse", "phospho_mse"])
    df_summary.insert(0, "sol_id", np.arange(len(df_summary), dtype=int))
    df_summary["w_prot"] = w_prot
    df_summary["w_rna"] = w_rna
    df_summary["w_phos"] = w_phos

    # scalar score for ranking / convenience
    df_summary["scalar_score"] = (
            w_prot * df_summary["prot_mse"]
            + w_rna * df_summary["rna_mse"]
            + w_phos * df_summary["phospho_mse"]
    )

    # rank: 1 = best
    df_summary["rank"] = df_summary["scalar_score"].rank(method="dense").astype(int)
    df_summary.sort_values(["scalar_score", "sol_id"], inplace=True, ignore_index=True)

    # which solutions get trajectories exported
    if top_k_trajectories is None:
        sol_ids_for_traj = df_summary["sol_id"].tolist()
    else:
        sol_ids_for_traj = df_summary.nsmallest(int(top_k_trajectories), "scalar_score")["sol_id"].tolist()

    # ---- Collect params + trajectories ----
    params_genes_rows = []
    params_kin_rows = []
    deg_site_rows = []
    traj_p_list = []
    traj_r_list = []
    traj_ph_list = []

    # Cache these for speed
    proteins = idx.proteins
    kinases = idx.kinases

    site_protein, site_psite, site_local = build_site_meta(idx)

    for sol_id in range(X.shape[0]):
        theta = X[sol_id].astype(float)
        p = unpack_params(theta, slices)

        # update system parameters
        sys.update(**p)

        # ----- parameters: genes (A,B,C,D,E + tf_scale) -----
        # long-form rows: sol_id, protein, param, value
        # (You can switch to wide format later in Excel easily)
        tf_scale_val = float(p["tf_scale"])
        for i, g in enumerate(proteins):
            params_genes_rows.append((sol_id, g, "A_i", float(p["A_i"][i])))
            params_genes_rows.append((sol_id, g, "B_i", float(p["B_i"][i])))
            params_genes_rows.append((sol_id, g, "C_i", float(p["C_i"][i])))
            params_genes_rows.append((sol_id, g, "D_i", float(p["D_i"][i])))
            params_genes_rows.append((sol_id, g, "E_i", float(p["E_i"][i])))
            params_genes_rows.append((sol_id, g, "tf_scale", tf_scale_val))

        # ---- per-site degradation rates ----
        # Prefer params dict if present, else sys attribute set by update().
        deg_vec = p.get("Dp_i")
        if deg_vec is None:
            deg_vec = p.get("deg_site")
        if deg_vec is None:
            deg_vec = p.get("kdeg_site")
        if deg_vec is None:
            deg_vec = getattr(sys, "Dp_i", None)

        if deg_vec is not None:
            deg_vec = np.asarray(deg_vec, dtype=float).reshape(-1)
            # Depending on how Dp_i is stored (sometimes it might be squeezed), ensure size matches
            if deg_vec.size != idx.total_sites:
                # If mismatch, try to see if it's a scalar broadcast
                if deg_vec.size == 1:
                    deg_vec = np.full(idx.total_sites, deg_vec.item())
                else:
                    logger.info(
                        f"Warning: Dp_i size {deg_vec.size} != total_sites {idx.total_sites}. Skipping deg_sites export.")
                    deg_vec = None

        if deg_vec is not None:
            for s in range(idx.total_sites):
                deg_site_rows.append((
                    sol_id,
                    int(s),
                    site_protein[s],
                    site_psite[s],
                    int(site_local[s]),
                    float(deg_vec[s]),
                ))

        # ----- parameters: kinases (c_k) -----
        for j, k in enumerate(kinases):
            params_kin_rows.append((sol_id, k, float(p["c_k"][j])))

        # ----- trajectories (optional / top-K) -----
        if sol_id in sol_ids_for_traj:
            # use your existing measurement function (calls simulate_odeint internally)
            dfp, dfr, dfph = simulate_and_measure(sys, idx, t_points_p, t_points_r, t_points_ph)

            if dfp is not None and not dfp.empty:
                dfp = dfp.copy()
                dfp.insert(0, "sol_id", sol_id)
                traj_p_list.append(dfp)

            if dfr is not None and not dfr.empty:
                dfr = dfr.copy()
                dfr.insert(0, "sol_id", sol_id)
                traj_r_list.append(dfr)

            if dfph is not None and not dfph.empty:
                dfph = dfph.copy()
                dfph.insert(0, "sol_id", sol_id)
                traj_ph_list.append(dfph)

    df_params_genes = pd.DataFrame(params_genes_rows, columns=["sol_id", "protein", "param", "value"])
    df_params_kin = pd.DataFrame(params_kin_rows, columns=["sol_id", "kinase", "c_k"])

    df_traj_p = pd.concat(traj_p_list, ignore_index=True) if traj_p_list else pd.DataFrame(
        columns=["sol_id", "protein", "time", "pred_fc"]
    )
    df_traj_r = pd.concat(traj_r_list, ignore_index=True) if traj_r_list else pd.DataFrame(
        columns=["sol_id", "protein", "time", "pred_fc"]
    )
    df_traj_ph = pd.concat(traj_ph_list, ignore_index=True) if traj_ph_list else pd.DataFrame(
        columns=["sol_id", "protein", "psite", "time", "pred_fc"]
    )
    df_deg_sites = pd.DataFrame(
        deg_site_rows,
        columns=["sol_id", "site_id", "protein", "psite", "local_site", "k_deg"]
    )

    # ---- Write Excel ----
    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        df_summary.to_excel(writer, sheet_name="summary", index=False)
        df_params_genes.to_excel(writer, sheet_name="params_genes", index=False)
        df_deg_sites.to_excel(writer, sheet_name="deg_sites", index=False)
        df_params_kin.to_excel(writer, sheet_name="params_kinases", index=False)
        df_traj_p.to_excel(writer, sheet_name="traj_protein", index=False)
        df_traj_r.to_excel(writer, sheet_name="traj_rna", index=False)
        df_traj_ph.to_excel(writer, sheet_name="traj_phospho", index=False)

    logger.info(f"[Output] Pareto export saved: {output_path}")
    logger.info(f"[Output] Solutions: {len(df_summary)} | Traj exported for: {len(sol_ids_for_traj)}")


def _standardize_merged_fc(df, obs_suffix="_obs", pred_suffix="_pred"):
    """
    Standardizes a merged DataFrame with suffixes to produce columns: fc_obs, fc_pred.
    Supports common input names: fc, pred_fc, fc_obs/fc_pred already present.

    Args:
        df: DataFrame with merged data.
        obs_suffix: Suffix for observed data columns.
        pred_suffix: Suffix for predicted data columns.

    Returns
    -------
        Standardized DataFrame with fc_obs and fc_pred columns.
    """
    if {"fc_obs", "fc_pred"}.issubset(df.columns):
        return df

    candidates = ["fc", "pred_fc", "obs_fc", "meas_fc"]

    obs_col = None
    pred_col = None
    for base in candidates:
        c_obs = f"{base}{obs_suffix}"
        c_pred = f"{base}{pred_suffix}"
        if c_obs in df.columns and c_pred in df.columns:
            obs_col, pred_col = c_obs, c_pred
            break

    if obs_col is None and pred_col is None:
        if "fc" in df.columns and "pred_fc" in df.columns:
            obs_col, pred_col = "fc", "pred_fc"
        elif "fc_obs" in df.columns and "pred_fc" in df.columns:
            obs_col, pred_col = "fc_obs", "pred_fc"
        elif "fc" in df.columns and "fc_pred" in df.columns:
            obs_col, pred_col = "fc", "fc_pred"

    if obs_col is None or pred_col is None:
        raise KeyError(
            f"Could not infer observed/predicted FC columns. "
            f"Columns seen: {list(df.columns)}"
        )

    out = df.copy()
    out.rename(columns={obs_col: "fc_obs", pred_col: "fc_pred"}, inplace=True)
    return out


def plot_goodness_of_fit(df_prot_obs, df_prot_pred,
                         df_rna_obs, df_rna_pred,
                         df_phos_obs, df_phos_pred,
                         output_dir, file_prefix=""):
    """
    Plots goodness of fit for protein, RNA, and phosphorylation data.

    Args:
        df_prot_obs: Protein observed data DataFrame.
        df_prot_pred: Protein predicted data DataFrame.
        df_rna_obs: RNA observed data DataFrame.
        df_rna_pred: RNA predicted data DataFrame.
        df_phos_obs: Phosphorylation observed data DataFrame.
        df_phos_pred: Phosphorylation predicted data DataFrame.
        output_dir: Directory where plots will be saved.
        file_prefix: Prefix for output file names.

    """

    def _robust_sigma(residuals: np.ndarray) -> float:
        """
        Calculates robust standard deviation of residuals.

        Args:
            residuals: Array of residuals (predicted - observed).

        Returns:
            Robust standard deviation estimate.
        """
        r = np.asarray(residuals, dtype=float)
        r = r[np.isfinite(r)]
        if r.size < 10:
            s = float(np.std(r))
            return s if s > 0 else 1e-12
        med = np.median(r)
        mad = np.median(np.abs(r - med))
        s = 1.4826 * mad
        if s <= 0:
            s = float(np.std(r))
        return float(s if s > 0 else 1e-12)

    def _annotate_unique(ax, df, xcol, ycol, label_col, *, max_labels=30):
        # most extreme first
        df = df.copy()
        df["abs_resid"] = np.abs(df[ycol] - df[xcol])
        df = df.sort_values("abs_resid", ascending=False)

        seen = set()
        n = 0
        for _, r in df.iterrows():
            lab = str(r[label_col])
            if lab in seen:
                continue
            seen.add(lab)

            ax.annotate(
                lab,
                (float(r[xcol]), float(r[ycol])),
                textcoords="offset points",
                xytext=(6, 6),
                fontsize=8,
                color="black",
                bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="gray", alpha=0.8),
            )
            n += 1
            if n >= max_labels:
                break

    def _plot_one(df, title_suffix: str, out_name: str):
        # style
        sns.set_style("whitegrid")
        fig, ax = plt.subplots(figsize=(10, 9))

        # same palette/markers
        category_styles = {
            "Protein": {"color": "#2E86AB", "marker": "o", "label": "Protein"},
            "RNA": {"color": "#A23B72", "marker": "s", "label": "RNA"},
            "Phosphorylation": {"color": "#F18F01", "marker": "^", "label": "Phosphorylation"}
        }

        # scatter by category (within df)
        for cat_type, style in category_styles.items():
            cat_data = df[df["Type"] == cat_type]
            if not cat_data.empty:
                ax.scatter(
                    cat_data["fc_obs"],
                    cat_data["fc_pred"],
                    c=style["color"],
                    marker=style["marker"],
                    s=50,
                    alpha=0.6,
                    edgecolors="black",
                    linewidths=0.5,
                    label=style["label"],
                    rasterized=True
                )

        # identity bounds
        all_vals = np.concatenate([df["fc_obs"].values, df["fc_pred"].values])
        xmin, xmax = np.min(all_vals), np.max(all_vals)
        ax.plot([xmin, xmax], [xmin, xmax], "k--", alpha=0.5, linewidth=1.5, zorder=0, label="Identity")

        # CI bands around identity (robust)
        resid = (df["fc_pred"] - df["fc_obs"]).to_numpy(dtype=float)
        sigma = _robust_sigma(resid)

        z95 = 1.959963984540054
        z99 = 2.5758293035489004
        d95 = z95 * sigma
        d99 = z99 * sigma

        ax.plot([xmin, xmax], [xmin + d95, xmax + d95], color="gray", linestyle="--", lw=1.2, alpha=0.8,
                label="95% band")
        ax.plot([xmin, xmax], [xmin - d95, xmax - d95], color="gray", linestyle="--", lw=1.2, alpha=0.8)

        ax.plot([xmin, xmax], [xmin + d99, xmax + d99], color="gray", linestyle=":", lw=1.2, alpha=0.8,
                label="99% band")
        ax.plot([xmin, xmax], [xmin - d99, xmax - d99], color="gray", linestyle=":", lw=1.2, alpha=0.8)

        # metrics (identity RMSE + R2 of regression)
        x = df["fc_obs"].values
        y = df["fc_pred"].values
        slope, intercept, r_value, p_value, std_err = linregress(x, y)
        r2 = r_value ** 2
        rmse = float(np.sqrt(np.mean((y - x) ** 2)))

        ax.text(
            0.05, 0.95,
            f"{title_suffix}:\n$R^2 = {r2:.3f}$\n$RMSE = {rmse:.3f}$\n$\\sigma_\\Delta={sigma:.3g}$",
            transform=ax.transAxes,
            va="top",
            fontsize=11,
            bbox=dict(boxstyle="round", facecolor="white", alpha=0.9, edgecolor="gray", linewidth=1)
        )

        # flag near/out 95% band and label (no circles)
        border_frac = 0.10
        near_lo = (1.0 - border_frac) * d95

        abs_resid = np.abs(resid)

        flag_out = abs_resid >= d95
        flag_near = (abs_resid >= near_lo) & (abs_resid < d95)

        # build label column (phospho includes psite)
        if "psite" in df.columns:
            df = df.copy()
            df["point_label"] = np.where(
                df["Type"] == "Phosphorylation",
                df["protein"].astype(str) + "|" + df["psite"].astype(str),
                df["protein"].astype(str)
            )
        else:
            df = df.copy()
            df["point_label"] = df["protein"].astype(str)

        df_out = df.loc[flag_out]
        df_near = df.loc[flag_near]

        _annotate_unique(ax, df_out, "fc_obs", "fc_pred", "point_label", max_labels=25)
        _annotate_unique(ax, df_near, "fc_obs", "fc_pred", "point_label", max_labels=15)

        ax.set_xlabel("Observed FC", fontsize=12, fontweight="bold")
        ax.set_ylabel("Predicted FC", fontsize=12, fontweight="bold")
        ax.set_title(f"Goodness of Fit: Global ODE Model{title_suffix}", fontsize=14, fontweight="bold", pad=15)

        ax.legend(loc="lower right", frameon=True, framealpha=0.9, edgecolor="gray")
        ax.grid(True, alpha=0.3, linewidth=0.5)
        ax.set_aspect("equal", adjustable="box")

        fig.tight_layout()
        os.makedirs(output_dir, exist_ok=True)
        out_path = os.path.join(output_dir, out_name)
        plt.savefig(out_path, dpi=300, bbox_inches="tight", facecolor="white")
        plt.close()
        logger.info(f"[Output] Saved Goodness of Fit plot to: {out_path}")

    # ------------------------------------------------------------
    # 1) Build merged data (unchanged)
    # ------------------------------------------------------------
    mp = df_prot_obs.merge(df_prot_pred, on=["protein", "time"], suffixes=("_obs", "_pred"))
    mr = df_rna_obs.merge(df_rna_pred, on=["protein", "time"], suffixes=("_obs", "_pred"))
    mph = df_phos_obs.merge(df_phos_pred, on=["protein", "psite", "time"], suffixes=("_obs", "_pred"))

    mp = _standardize_merged_fc(mp)
    mr = _standardize_merged_fc(mr)
    mph = _standardize_merged_fc(mph)

    mp["Type"] = "Protein"
    mr["Type"] = "RNA"
    mph["Type"] = "Phosphorylation"

    combined = pd.concat([mp, mr, mph], ignore_index=True).dropna(subset=["fc_obs", "fc_pred"])

    # ------------------------------------------------------------
    # 2) Full combined plot
    # ------------------------------------------------------------
    _plot_one(
        combined,
        title_suffix=" (Overall)",
        out_name=f"{file_prefix}goodness_of_fit.png"
    )

    # ------------------------------------------------------------
    # 3) Per-modality plots
    # ------------------------------------------------------------
    for typ in ["Protein", "RNA", "Phosphorylation"]:
        sub = combined[combined["Type"] == typ].copy()
        if sub.empty:
            continue
        _plot_one(
            sub,
            title_suffix=f" ({typ})",
            out_name=f"{file_prefix}goodness_of_fit_{typ}.png"
        )


def plot_gof_from_pareto_excel(
        excel_path: str,
        output_dir: str,
        plot_goodness_of_fit_func,
        df_prot_obs_all: pd.DataFrame,
        df_rna_obs_all: pd.DataFrame,
        df_phos_obs_all: pd.DataFrame,
        traj_protein_sheet: str = "traj_protein",
        traj_rna_sheet: str = "traj_rna",
        traj_phospho_sheet: str = "traj_phospho",
        summary_sheet: str = "summary",
        top_k: int = None,
        only_solutions=None,
        score_col: str = "scalar_score",
):
    """
    Uses the Excel produced by export_pareto_front_to_excel to plot goodness of fit

      - summary
      - traj_protein (sol_id, protein, time, pred_fc)
      - traj_rna     (sol_id, protein, time, pred_fc)
      - traj_phospho (sol_id, protein, psite, time, pred_fc)
    """
    os.makedirs(output_dir, exist_ok=True)

    xls = pd.ExcelFile(excel_path)
    for s in [traj_protein_sheet, traj_rna_sheet, traj_phospho_sheet, summary_sheet]:
        if s not in xls.sheet_names:
            raise ValueError(f"Missing sheet '{s}' in {excel_path}. Found: {xls.sheet_names}")

    df_sum = pd.read_excel(xls, sheet_name=summary_sheet)
    if "sol_id" not in df_sum.columns:
        raise ValueError(f"'{summary_sheet}' must contain 'sol_id' column.")
    if score_col not in df_sum.columns:
        # still ok, but then top_k by score_col can't work
        if top_k is not None:
            raise ValueError(f"top_k requested but '{summary_sheet}' has no '{score_col}' column.")

    # choose sol_ids
    sol_ids = df_sum["sol_id"].astype(int).tolist()

    if only_solutions is not None:
        only = set(int(x) for x in only_solutions)
        sol_ids = [sid for sid in sol_ids if sid in only]

    if top_k is not None:
        df_rank = df_sum.sort_values(score_col, ascending=True)
        sol_ids = df_rank["sol_id"].astype(int).head(int(top_k)).tolist()

    if not sol_ids:
        raise ValueError("No solutions selected to plot.")

    # load trajectories once
    traj_p = pd.read_excel(xls, sheet_name=traj_protein_sheet)
    traj_r = pd.read_excel(xls, sheet_name=traj_rna_sheet)
    traj_ph = pd.read_excel(xls, sheet_name=traj_phospho_sheet)

    # sanity required columns
    for name, df in [("traj_protein", traj_p), ("traj_rna", traj_r)]:
        need = {"sol_id", "protein", "time", "pred_fc"}
        missing = need - set(df.columns)
        if missing:
            raise ValueError(f"Sheet '{name}' missing columns: {sorted(missing)}")

    for name, df in [("traj_phospho", traj_ph)]:
        need = {"sol_id", "protein", "psite", "time", "pred_fc"}
        missing = need - set(df.columns)
        if missing:
            raise ValueError(f"Sheet '{name}' missing columns: {sorted(missing)}")

    # ensure types
    traj_p["sol_id"] = pd.to_numeric(traj_p["sol_id"], errors="coerce").astype("Int64")
    traj_r["sol_id"] = pd.to_numeric(traj_r["sol_id"], errors="coerce").astype("Int64")
    traj_ph["sol_id"] = pd.to_numeric(traj_ph["sol_id"], errors="coerce").astype("Int64")

    traj_p["time"] = pd.to_numeric(traj_p["time"], errors="coerce")
    traj_r["time"] = pd.to_numeric(traj_r["time"], errors="coerce")
    traj_ph["time"] = pd.to_numeric(traj_ph["time"], errors="coerce")

    # observed must have protein,time,fc
    for df_name, df in [("df_prot_obs_all", df_prot_obs_all), ("df_rna_obs_all", df_rna_obs_all)]:
        for col in ["protein", "time", "fc"]:
            if col not in df.columns and not df.empty:
                raise ValueError(f"{df_name} must have columns: protein,time,fc. Missing: {col}")

    for df_name, df in [("df_phos_obs_all", df_phos_obs_all)]:
        for col in ["protein", "psite", "time", "fc"]:
            if col not in df.columns and not df.empty:
                raise ValueError(f"{df_name} must have columns: protein,psite,time,fc. Missing: {col}")

    # loop solutions
    for sid in sol_ids:
        sid = int(sid)

        sub_p = traj_p[traj_p["sol_id"] == sid].copy()
        sub_r = traj_r[traj_r["sol_id"] == sid].copy()
        sub_ph = traj_ph[traj_ph["sol_id"] == sid].copy()

        if sub_p.empty and sub_r.empty:
            continue

        # build pred dfs in the format your plot_goodness_of_fit expects:
        # df_*_pred must have columns: protein,time,pred_fc
        df_prot_pred = sub_p[["protein", "time", "pred_fc"]].copy()
        df_rna_pred = sub_r[["protein", "time", "pred_fc"]].copy()
        df_phos_pred = sub_ph[["protein", "psite", "time", "pred_fc"]].copy()

        # observed: subset to the times/proteins present in preds (keeps merge tight)
        if not df_prot_pred.empty:
            keys_p = df_prot_pred[["protein", "time"]].drop_duplicates()
            df_prot_obs = df_prot_obs_all.merge(keys_p, on=["protein", "time"], how="inner")
        else:
            df_prot_obs = df_prot_obs_all.iloc[0:0].copy()

        if not df_rna_pred.empty:
            keys_r = df_rna_pred[["protein", "time"]].drop_duplicates()
            df_rna_obs = df_rna_obs_all.merge(keys_r, on=["protein", "time"], how="inner")
        else:
            df_rna_obs = df_rna_obs_all.iloc[0:0].copy()

        if not df_phos_pred.empty:
            keys_ph = df_phos_pred[["protein", "psite", "time"]].drop_duplicates()
            df_phos_obs = df_phos_obs_all.merge(keys_ph, on=["protein", "psite", "time"], how="inner")
        else:
            df_phos_obs = df_phos_obs_all.iloc[0:0].copy()

        sol_dir = output_dir

        plot_goodness_of_fit_func(
            df_prot_obs=df_prot_obs,
            df_prot_pred=df_prot_pred,
            df_rna_obs=df_rna_obs,
            df_rna_pred=df_rna_pred,
            df_phos_obs=df_phos_obs,
            df_phos_pred=df_phos_pred,
            output_dir=sol_dir,
            file_prefix=f"sol_{sid}_"
        )

    logger.info(f"[Output] Goodness of fit plots generated for {len(sol_ids)} solutions into: {output_dir}")


def export_results(
        sys,
        idx,
        df_prot_obs,
        df_rna_obs,
        df_phos_obs,
        df_pred_p,
        df_pred_r,
        df_pred_ph,
        output_dir,
):
    """
    Export pre-computed observed + predicted trajectories and model parameters.

    Args:
        sys: System object containing model information.
        idx: Index of the solution to export.
        df_prot_obs: Protein observed data DataFrame.
        df_rna_obs: RNA observed data DataFrame.
        df_phos_obs: Phosphorylation observed data DataFrame.
        df_pred_p: Protein predicted data DataFrame.
        df_pred_r: RNA predicted data DataFrame.
        df_pred_ph: Phosphorylation predicted data DataFrame.
        output_dir: Directory where results will be saved.
    """
    os.makedirs(output_dir, exist_ok=True)

    def _merge_traj(obs_df, pred_df, on_cols, traj_type):
        obs = obs_df.rename(columns={"fc": "fc_obs"}).copy()
        pred = pred_df.rename(columns={"pred_fc": "fc_pred"}).copy()
        merged = obs.merge(pred, on=on_cols, how="outer")
        merged["type"] = traj_type
        if "psite" not in merged.columns:
            merged["psite"] = np.nan
        return merged

    logger.info("[Output] Exporting Trajectories...")

    merged_p = _merge_traj(df_prot_obs, df_pred_p, on_cols=["protein", "time"], traj_type="Protein")
    merged_r = _merge_traj(df_rna_obs, df_pred_r, on_cols=["protein", "time"], traj_type="RNA")
    merged_ph = _merge_traj(df_phos_obs, df_pred_ph, on_cols=["protein", "psite", "time"], traj_type="Phosphorylation")

    full_traj = pd.concat([merged_p, merged_r, merged_ph], ignore_index=True)
    full_traj = full_traj[["type", "protein", "psite", "time", "fc_obs", "fc_pred"]]
    full_traj.sort_values(["type", "protein", "psite", "time"], inplace=True)

    full_traj.to_csv(os.path.join(output_dir, "model_trajectories.csv"), index=False)

    logger.info("[Output] Exporting Parameters...")

    # --- Gene/protein-level parameters (one row per protein) ---
    N = len(idx.proteins)

    dp_mean = np.full(N, np.nan, dtype=float)
    dp_min = np.full(N, np.nan, dtype=float)
    dp_max = np.full(N, np.nan, dtype=float)

    for i in range(N):
        ns = int(idx.n_sites[i])
        if ns > 0:
            s0 = int(idx.offset_s[i])
            dps = np.asarray(sys.Dp_i[s0:s0 + ns], dtype=float)  # per-site Dp for this protein
            dp_mean[i] = float(np.mean(dps))
            dp_min[i] = float(np.min(dps))
            dp_max[i] = float(np.max(dps))

    df_params_genes = pd.DataFrame(
        {
            "Protein_Gene": idx.proteins,
            "Synthesis_A": sys.A_i,
            "mRNA_Degradation_B": sys.B_i,
            "Translation_C": sys.C_i,
            "Protein_Degradation_D": sys.D_i,
            "Phospho_Degradation_Dp_mean": dp_mean,
            "Phospho_Degradation_Dp_min": dp_min,
            "Phospho_Degradation_Dp_max": dp_max,
            "De-Phosphorylation_E": sys.E_i,
            "Global_TF_Scale": np.full(N, sys.tf_scale, dtype=float),
        }
    )

    df_params_genes.to_csv(os.path.join(output_dir, "model_parameters_genes.csv"), index=False)

    # --- Gene/protein x psite parameters (long format) ---
    # psites come from observed phos dataframe (can switch to df_pred_ph if preferred)
    psites_by_protein = (
        df_phos_obs[["protein", "psite"]]
        .dropna()
        .drop_duplicates()
        .groupby("protein")["psite"]
        .apply(lambda s: sorted(s.unique()))
        .to_dict()
    )

    rows = []
    for i, prot in enumerate(idx.proteins):
        ns = int(idx.n_sites[i])
        s0 = int(idx.offset_s[i])

        if ns == 0:
            # no sites -> one row with NaNs for site-specific values
            rows.append(
                {
                    "Protein_Gene": prot,
                    "psite": np.nan,
                    "Synthesis_A": sys.A_i[i],
                    "mRNA_Degradation_B": sys.B_i[i],
                    "Translation_C": sys.C_i[i],
                    "Protein_Degradation_D": sys.D_i[i],
                    "Phospho_Degradation_Dp": np.nan,
                    "De-Phosphorylation_E": sys.E_i[i],
                    "Global_TF_Scale": sys.tf_scale,
                }
            )
            continue

        # map psite -> local index j
        site_to_j = {ps: j for j, ps in enumerate(idx.sites[i])}

        psite_list = psites_by_protein.get(prot, [])
        for psite in psite_list:
            j = site_to_j.get(psite, None)
            dp_val = float(sys.Dp_i[s0 + j]) if j is not None else np.nan

            rows.append(
                {
                    "Protein_Gene": prot,
                    "psite": psite,
                    "Synthesis_A": sys.A_i[i],
                    "mRNA_Degradation_B": sys.B_i[i],
                    "Translation_C": sys.C_i[i],
                    "Protein_Degradation_D": sys.D_i[i],
                    "Phospho_Degradation_Dp": dp_val,
                    "De-Phosphorylation_E": sys.E_i[i],
                    "Global_TF_Scale": sys.tf_scale,
                }
            )

    df_params_genes_psites = pd.DataFrame(rows)
    df_params_genes_psites.to_csv(
        os.path.join(output_dir, "model_parameters_genes_psites.csv"),
        index=False,
    )

    # --- Kinase parameters ---
    df_kin_params = pd.DataFrame(
        {
            "Kinase": idx.kinases,
            "Activity_Scale_ck": sys.c_k,
        }
    )
    df_kin_params.to_csv(os.path.join(output_dir, "model_parameters_kinases.csv"), index=False)

    logger.info(f"[Output] Exports saved to {output_dir}")


def save_gene_timeseries_plots(
        gene: str,
        df_prot_obs: pd.DataFrame,
        df_prot_pred: pd.DataFrame,
        df_rna_obs: pd.DataFrame,
        df_rna_pred: pd.DataFrame,
        df_phos_obs: pd.DataFrame,
        df_phos_pred: pd.DataFrame,
        output_dir: str,
        prot_times: np.ndarray = None,
        rna_times: np.ndarray = None,
        phos_times: np.ndarray = None,
        filename_prefix: str = "ts",
        dpi: int = 300,
        phos_mode: str = "per_psite",  # "mean" or "per_psite"
        max_psites: int = None,  # only used for per_psite
):
    """
    Save a 3-panel time-series plot for one protein link:
      - Protein observed vs predicted (fc vs fc_pred)
      - RNA observed vs predicted
      - Phosphorylation observed vs predicted (either mean across psites or per-psite lines

    """
    os.makedirs(output_dir, exist_ok=True)

    def _norm_pred(df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        if "fc_pred" not in df.columns and "pred_fc" in df.columns:
            df.rename(columns={"pred_fc": "fc_pred"}, inplace=True)
        if "fc_pred" not in df.columns:
            raise ValueError(f"Pred df must have 'pred_fc' or 'fc_pred'. Got: {list(df.columns)}")
        return df

    def _clean_ts(df: pd.DataFrame, value_col: str, time_col: str = "time") -> pd.DataFrame:
        if df is None or df.empty:
            return df
        out = df.copy()
        out[time_col] = pd.to_numeric(out[time_col], errors="coerce")
        out[value_col] = pd.to_numeric(out[value_col], errors="coerce")
        out.dropna(subset=[time_col, value_col], inplace=True)
        out.sort_values(time_col, inplace=True)
        return out

    def _lighten(color, amount=0.65):
        r, g, b = mcolors.to_rgb(color)
        return (1 - amount) * r + amount, (1 - amount) * g + amount, (1 - amount) * b + amount

    # Normalize preds
    prot_pred = _norm_pred(df_prot_pred) if df_prot_pred is not None else pd.DataFrame()
    rna_pred = _norm_pred(df_rna_pred) if df_rna_pred is not None else pd.DataFrame()
    phos_pred = _norm_pred(df_phos_pred) if df_phos_pred is not None else pd.DataFrame()

    # Subset gene
    p_obs = df_prot_obs[df_prot_obs["protein"] == gene].copy() if df_prot_obs is not None else pd.DataFrame()
    p_pre = prot_pred[prot_pred["protein"] == gene].copy() if not prot_pred.empty else pd.DataFrame()

    r_obs = df_rna_obs[df_rna_obs["protein"] == gene].copy() if df_rna_obs is not None else pd.DataFrame()
    r_pre = rna_pred[rna_pred["protein"] == gene].copy() if not rna_pred.empty else pd.DataFrame()

    ph_obs = df_phos_obs[df_phos_obs["protein"] == gene].copy() if df_phos_obs is not None else pd.DataFrame()
    ph_pre = phos_pred[phos_pred["protein"] == gene].copy() if not phos_pred.empty else pd.DataFrame()

    # If truly nothing exists, bail
    if p_obs.empty and p_pre.empty and r_obs.empty and r_pre.empty and ph_obs.empty and ph_pre.empty:
        return None

    # Optional time filtering
    if prot_times is not None:
        p_obs = p_obs[p_obs["time"].isin(prot_times)]
        p_pre = p_pre[p_pre["time"].isin(prot_times)]
    if rna_times is not None:
        r_obs = r_obs[r_obs["time"].isin(rna_times)]
        r_pre = r_pre[r_pre["time"].isin(rna_times)]
    if phos_times is not None:
        ph_obs = ph_obs[ph_obs["time"].isin(phos_times)]
        ph_pre = ph_pre[ph_pre["time"].isin(phos_times)]

    # Clean numeric + sort
    p_obs = _clean_ts(p_obs, "fc")
    p_pre = _clean_ts(p_pre, "fc_pred")
    r_obs = _clean_ts(r_obs, "fc")
    r_pre = _clean_ts(r_pre, "fc_pred")

    # phospho cleaning (needs psite too, but same numeric cleaning)
    if not ph_obs.empty:
        ph_obs = _clean_ts(ph_obs, "fc")
    if not ph_pre.empty:
        ph_pre = _clean_ts(ph_pre, "fc_pred")

    # ---- Plot ----
    fig, axes = plt.subplots(1, 3, figsize=(20, 6), sharey=True)
    ax_p, ax_r, ax_ph = axes
    prot_c = "C0"
    rna_c = "C1"
    phos_c = "C2"

    obs_alpha = 0.35
    pred_alpha = 1.0

    prot_obs_c = _lighten(prot_c, 0.65)
    rna_obs_c = _lighten(rna_c, 0.65)
    phos_obs_c = _lighten(phos_c, 0.65)

    # Protein
    if not p_obs.empty:
        ax_p.plot(p_obs["time"].to_numpy(), p_obs["fc"].to_numpy(),
                  marker="s", linewidth=1, label="obs",
                  color=prot_obs_c, alpha=obs_alpha)
    if not p_pre.empty:
        ax_p.plot(p_pre["time"].to_numpy(), p_pre["fc_pred"].to_numpy(),
                  linewidth=2, label="pred",
                  color=prot_c, alpha=pred_alpha)
    ax_p.set_title(f"{gene} — Protein")
    ax_p.set_xlabel("Time")
    ax_p.set_ylabel("FC")
    ax_p.grid(True, alpha=0.3)
    ax_p.legend()

    # RNA
    if not r_obs.empty:
        ax_r.plot(r_obs["time"].to_numpy(), r_obs["fc"].to_numpy(),
                  marker="s", linewidth=1, label="obs",
                  color=rna_obs_c, alpha=obs_alpha)
    if not r_pre.empty:
        ax_r.plot(r_pre["time"].to_numpy(), r_pre["fc_pred"].to_numpy(),
                  linewidth=2, label="pred",
                  color=rna_c, alpha=pred_alpha)

    ax_r.set_title(f"{gene} — mRNA")
    ax_r.set_xlabel("Time")
    ax_r.set_ylabel("FC")
    ax_r.grid(True, alpha=0.3)
    ax_r.legend()

    # Phospho
    ax_ph.set_title(f"{gene} — Phosphorylation")
    ax_ph.set_xlabel("Time")
    ax_ph.set_ylabel("FC")
    ax_ph.grid(True, alpha=0.3)

    if phos_mode not in {"mean", "per_psite"}:
        raise ValueError("phos_mode must be 'mean' or 'per_psite'")

    if not ph_obs.empty or not ph_pre.empty:
        if phos_mode == "mean":
            # mean across psites at each time
            if not ph_obs.empty:
                obs_mean = ph_obs.groupby("time", as_index=False)["fc"].mean()
                ax_ph.plot(obs_mean["time"].to_numpy(), obs_mean["fc"].to_numpy(),
                           marker="s", linewidth=1, label="obs (mean)",
                           color=phos_obs_c, alpha=obs_alpha)

            if not ph_pre.empty:
                pre_mean = ph_pre.groupby("time", as_index=False)["fc_pred"].mean()
                ax_ph.plot(pre_mean["time"].to_numpy(), pre_mean["fc_pred"].to_numpy(),
                           linewidth=2, label="pred (mean)",
                           color=phos_c, alpha=pred_alpha)
        else:
            # per-psite lines (capped)
            psites = sorted(set(ph_obs["psite"].unique()).union(set(ph_pre["psite"].unique()))) if (
                    "psite" in ph_obs.columns or "psite" in ph_pre.columns) else []

            # if len(psites) > max_psites:
            #     psites = psites[:max_psites]

            for ps in psites:
                ps_color = f"C{hash(ps) % 10}"
                ps_obs_color = _lighten(ps_color, 0.65)

                if not ph_obs.empty:
                    subo = ph_obs[ph_obs["psite"] == ps]
                    if not subo.empty:
                        ax_ph.plot(subo["time"].to_numpy(), subo["fc"].to_numpy(),
                                   marker="s", linewidth=1, label=f"obs {ps}",
                                   color=ps_obs_color, alpha=obs_alpha)

                if not ph_pre.empty:
                    subp = ph_pre[ph_pre["psite"] == ps]
                    if not subp.empty:
                        ax_ph.plot(subp["time"].to_numpy(), subp["fc_pred"].to_numpy(),
                                   linewidth=2, label=f"pred {ps}",
                                   color=ps_color, alpha=pred_alpha)

        ax_ph.legend(ncol=2, fontsize=8)

    fig.suptitle(f"Observed vs Predicted Time Series — {gene}", y=0.995)
    fig.tight_layout()

    out_path = os.path.join(output_dir, f"{filename_prefix}_{gene}.png")
    fig.savefig(out_path, dpi=dpi, bbox_inches="tight")
    plt.close(fig)
    return out_path


def scan_prior_reg(out_dir):
    """
    Scan prior regularization parameters and save Pareto front plots.

    Args:
        out_dir: Directory containing output files.
    """
    F = np.load(os.path.join(out_dir, "pareto_F.npy"))

    if F.ndim != 2 or F.shape[1] != 3:
        raise ValueError(f"Expected F shape (n, 3) = [prot_mse, rna_mse, phospho_mse]. Got {F.shape}")

    lambda_prot_grid = np.logspace(-2, 2, 9)  # 0.01 .. 100
    lambda_rna_grid = np.logspace(-2, 2, 9)  # 0.01 .. 100
    lambda_phos_grid = np.logspace(-2, 2, 9)  # 0.01 .. 100
    lambda_prior_grid = np.logspace(-4, 0, 9)  # 1e-4 .. 1

    prot = F[:, 0].astype(float)
    rna = F[:, 1].astype(float)
    phos = F[:, 2].astype(float)

    rows = []
    for lprot in lambda_prot_grid:
        for lrna in lambda_rna_grid:
            for լph in lambda_phos_grid:
                base = (float(lprot) * prot) + (float(lrna) * rna) + (float(լph) * phos)

                for lprior in lambda_prior_grid:
                    if float(lprior) <= 0:
                        raise ValueError("lambda_prior must be > 0 to preserve ordering / meaning.")

                    score = float(lprior) * base
                    best_i = int(np.argmin(score))
                    best_score = float(score[best_i])

                    rows.append({
                        "lambda_prot": float(lprot),
                        "lambda_rna": float(lrna),
                        "lambda_phospho": float(լph),
                        "lambda_prior": float(lprior),
                        "best_i": best_i,
                        "best_score": best_score,
                        "prot_mse": float(prot[best_i]),
                        "rna_mse": float(rna[best_i]),
                        "phospho_mse": float(phos[best_i]),
                    })

    df = pd.DataFrame(rows).sort_values(
        ["lambda_prot", "lambda_rna", "lambda_phospho", "lambda_prior"],
        ignore_index=True
    )
    df.to_csv(os.path.join(out_dir, "lambda_scan.csv"), index=False)

    # also save the unique picked solutions (often repeats)
    uniq = df.drop_duplicates("best_i").copy()
    uniq.to_csv(os.path.join(out_dir, "lambda_scan_unique_picks.csv"), index=False)

    # “recommended” choice: pick the best (prot, then rna, then phos) among unique picks
    cand = uniq.sort_values(["prot_mse", "rna_mse", "phospho_mse"], ignore_index=True).iloc[0]
    rec = {
        "lambda_prot": float(cand["lambda_prot"]),
        "lambda_rna": float(cand["lambda_rna"]),
        "lambda_phospho": float(cand["lambda_phospho"]),
        "lambda_prior": float(cand["lambda_prior"]),
        "best_i": int(cand["best_i"]),
        "objectives": {
            "prot_mse": float(cand["prot_mse"]),
            "rna_mse": float(cand["rna_mse"]),
            "phospho_mse": float(cand["phospho_mse"]),
        },
        "note": "lambda_prior is a global multiplier; it does not change best_i for fixed F (only rescales best_score).",
    }
    with open(os.path.join(out_dir, "lambda_scan_recommended.json"), "w") as f:
        json.dump(rec, f, indent=2)

    logger.info(
        "[Output] Lambda scan complete. "
    )

    return df, uniq, rec


def export_S_rates(sys, idx, output_dir, filename="S_rates_picked.csv", long=True):
    """
    Export phosphorylation drive S for optimized parameters.
    S is per-site and per time-bin (TIME_POINTS_PROTEIN / sys.kin_grid).

    Args:
        sys: System object containing model information.
        idx: Index of the solution to export.
        output_dir: Directory where results will be saved.
        filename: Name of the output file.
        long: If True, output in long format (protein, psite, time, S); otherwise, wide format.
    """
    os.makedirs(output_dir, exist_ok=True)

    # ---- compute S matrix: shape (total_sites, n_bins) ----
    if MODEL == 2:
        # Ensure cache matches current optimized c_k
        build_S_cache_into(sys.S_cache, sys.W_indptr, sys.W_indices, sys.W_data, sys.kin_Kmat, sys.c_k)
        S_mat = np.asarray(sys.S_cache, dtype=np.float64)
        times = np.asarray(sys.kin_grid, dtype=float)
    else:
        # Dense kinase signal scaled by c_k
        K_scaled = (np.asarray(sys.kin_Kmat, dtype=np.float64) *
                    np.asarray(sys.c_k, dtype=np.float64)[:, None])  # (n_kin, n_bins)
        # Sparse (total_sites x n_kin) dot dense (n_kin x n_bins) -> (total_sites x n_bins)
        S_mat = sys.W_global.dot(K_scaled)
        S_mat = np.asarray(S_mat, dtype=np.float64)
        times = np.asarray(sys.kin_grid, dtype=float)

    # ---- build (protein, psite) mapping in the exact row order of W / S_mat ----
    proteins = []
    psites = []
    for i, p in enumerate(idx.proteins):
        for s in idx.sites[i]:
            proteins.append(p)
            psites.append(s)

    if len(proteins) != S_mat.shape[0]:
        raise RuntimeError(
            f"Row mapping mismatch: mapped {len(proteins)} sites but S_mat has {S_mat.shape[0]} rows. "
            f"Check idx.sites ordering vs W construction."
        )

    if long:
        # long format: repeat each site across all time bins
        n_sites, n_bins = S_mat.shape
        df = pd.DataFrame({
            "protein": np.repeat(np.array(proteins, dtype=object), n_bins),
            "psite": np.repeat(np.array(psites, dtype=object), n_bins),
            "time": np.tile(times, n_sites),
            "S": S_mat.reshape(-1),
        })
    else:
        # wide format: one row per site, one column per time
        cols = [f"S_t{t:g}" for t in times]
        df = pd.DataFrame(S_mat, columns=cols)
        df.insert(0, "psite", psites)
        df.insert(0, "protein", proteins)

    out_path = os.path.join(output_dir, filename)
    df.to_csv(out_path, index=False)
    logger.info(f"[Output] Saved S rates to: {out_path}")
    return df


def plot_s_rates_report(
        csv_path: str | Path,
        out_pdf: str | Path = "S_rates_report.pdf",
        *,
        time_col: str = "time",
        value_col: str = "S",
        protein_col: str = "protein",
        psite_col: str = "psite",
        log_x: bool = True,
        # keep plots readable for many sites
        top_k_sites_per_protein: int | None = 24,  # rank by AUC and keep only top K per protein in "small multiples"
        max_sites_per_page: int = 12,  # small-multiples pagination
        ncols: int = 3,  # small-multiples grid columns
        normalize_per_site: bool = False,  # if True: plot S/Smax to compare kinetics
        heatmap_per_protein: bool = True,
        heatmap_cap_sites: int = 80,  # cap number of rows in a heatmap (rank by AUC)
        agg_duplicates: str = "mean",  # if repeated (protein,psite,time)
        dpi: int = 150,
) -> Path:
    """
    Plot phosphorylation drive S for optimized parameters.
    """
    csv_path = Path(csv_path)
    out_pdf = Path(out_pdf)

    df = pd.read_csv(csv_path)

    need = {protein_col, psite_col, time_col, value_col}
    missing = need - set(df.columns)
    if missing:
        raise ValueError(f"Missing columns {missing}. Got: {list(df.columns)}")

    # coerce + clean
    df = df[[protein_col, psite_col, time_col, value_col]].copy()
    df[time_col] = pd.to_numeric(df[time_col], errors="coerce")
    df[value_col] = pd.to_numeric(df[value_col], errors="coerce")
    df = df.dropna(subset=[protein_col, psite_col, time_col, value_col])

    # aggregate duplicates (same protein, site, time)
    if agg_duplicates:
        df = (
            df.groupby([protein_col, psite_col, time_col], as_index=False)[value_col]
            .agg(agg_duplicates)
        )

    # sort
    df.sort_values([protein_col, psite_col, time_col], inplace=True)

    # compute AUC per (protein, psite) to rank sites
    def _auc(g: pd.DataFrame) -> float:
        t = g[time_col].to_numpy(dtype=float)
        y = g[value_col].to_numpy(dtype=float)
        if t.size < 2:
            return float(y[0]) if y.size else 0.0
        # trapz assumes t sorted
        return float(np.trapz(y, t))

    auc_df = (
        df.groupby([protein_col, psite_col], as_index=False)
        .apply(_auc)
        .reset_index()
    )
    # pandas groupby.apply output can be awkward depending on version
    if "level_0" in auc_df.columns and 0 in auc_df.columns:
        auc_df = auc_df.rename(columns={"level_0": protein_col, "level_1": psite_col, 0: "AUC"})
    elif 0 in auc_df.columns:
        auc_df = auc_df.rename(columns={0: "AUC"})
    elif "AUC" not in auc_df.columns:
        # fallback: rebuild robustly
        rows = []
        for (p, s), g in df.groupby([protein_col, psite_col]):
            rows.append((p, s, _auc(g)))
        auc_df = pd.DataFrame(rows, columns=[protein_col, psite_col, "AUC"])

    auc_df["AUC"] = pd.to_numeric(auc_df["AUC"], errors="coerce").fillna(0.0)
    auc_df.sort_values(["AUC"], ascending=False, inplace=True)

    # early vs late means for global scatter
    tmin = float(df[time_col].min())
    tmax = float(df[time_col].max())
    # choose early/late cutoffs that match your grids
    early_cut = 2.0
    late_cut = 120.0

    early = (
        df[df[time_col] <= early_cut]
        .groupby([protein_col, psite_col])[value_col]
        .mean()
        .rename("early_S")
    )
    late = (
        df[df[time_col] >= late_cut]
        .groupby([protein_col, psite_col])[value_col]
        .mean()
        .rename("late_S")
    )
    el = pd.concat([early, late], axis=1).dropna().reset_index()

    # ---------- plotting helpers ----------
    def _apply_xscale(ax):
        if log_x:
            # avoid log(0): shift zeros to smallest positive tick if needed
            ax.set_xscale("symlog" if (df[time_col] == 0).any() else "log")

    def _small_multiples_for_protein(pdf: PdfPages, prot: str, sub: pd.DataFrame):
        # rank this protein's sites by AUC
        sub_auc = auc_df[auc_df[protein_col] == prot].sort_values("AUC", ascending=False)
        sites_ranked = sub_auc[psite_col].tolist()
        if top_k_sites_per_protein is not None:
            sites_ranked = sites_ranked[: int(top_k_sites_per_protein)]

        # paginate
        pages = max(1, math.ceil(len(sites_ranked) / max_sites_per_page))
        for page in range(pages):
            chunk = sites_ranked[page * max_sites_per_page: (page + 1) * max_sites_per_page]
            if not chunk:
                continue

            n = len(chunk)
            nrows = math.ceil(n / ncols)

            fig, axes = plt.subplots(
                nrows=nrows, ncols=ncols,
                figsize=(3.8 * ncols, 2.7 * nrows),
                squeeze=False
            )
            axes = axes.ravel()

            for ax_i, site in enumerate(chunk):
                ax = axes[ax_i]
                g = sub[sub[psite_col] == site]
                t = g[time_col].to_numpy(dtype=float)
                y = g[value_col].to_numpy(dtype=float)

                if normalize_per_site:
                    mx = float(np.max(y)) if y.size else 1.0
                    y = y / (mx if mx > 0 else 1.0)

                ax.plot(t, y, marker="o", linewidth=1.5, markersize=3)
                _apply_xscale(ax)
                ax.set_title(f"{prot}  {site}", fontsize=9)
                ax.grid(True, alpha=0.25)

                if ax_i % ncols == 0:
                    ax.set_ylabel("S" if not normalize_per_site else "S / max(S)")
                ax.set_xlabel("time")

            # turn off unused axes
            for j in range(n, len(axes)):
                axes[j].axis("off")

            fig.suptitle(
                f"{prot} — site time series"
                + (" (normalized)" if normalize_per_site else "")
                + (f" — page {page + 1}/{pages}" if pages > 1 else ""),
                fontsize=12
            )
            fig.tight_layout(rect=[0, 0, 1, 0.96])
            pdf.savefig(fig, dpi=dpi)
            plt.close(fig)

    def _heatmap_for_protein(pdf: PdfPages, prot: str, sub: pd.DataFrame):
        # pivot sites x times
        sub_auc = auc_df[auc_df[protein_col] == prot].sort_values("AUC", ascending=False)
        sites_ranked = sub_auc[psite_col].tolist()
        if heatmap_cap_sites is not None:
            sites_ranked = sites_ranked[: int(heatmap_cap_sites)]

        sub2 = sub[sub[psite_col].isin(sites_ranked)]
        piv = sub2.pivot(index=psite_col, columns=time_col, values=value_col)

        # reorder columns by time
        piv = piv.reindex(sorted(piv.columns), axis=1)

        # optionally normalize rows
        mat = piv.to_numpy(dtype=float)
        if normalize_per_site:
            row_max = np.nanmax(mat, axis=1)
            row_max[row_max <= 0] = 1.0
            mat = mat / row_max[:, None]

        fig, ax = plt.subplots(figsize=(10.5, max(3.5, 0.18 * mat.shape[0])))
        im = ax.imshow(mat, aspect="auto", interpolation="nearest")
        ax.set_title(
            f"{prot} — heatmap (top {len(sites_ranked)} sites by AUC)"
            + (" — normalized" if normalize_per_site else ""),
            fontsize=12
        )
        ax.set_ylabel("psite")
        ax.set_xlabel("time")

        # ticks
        ax.set_yticks(np.arange(len(piv.index)))
        ax.set_yticklabels(piv.index.tolist(), fontsize=7)

        xt = piv.columns.to_list()
        ax.set_xticks(np.arange(len(xt)))
        ax.set_xticklabels([str(x) for x in xt], rotation=45, ha="right", fontsize=8)

        cbar = fig.colorbar(im, ax=ax)
        cbar.set_label("S" if not normalize_per_site else "S / max(S)")

        fig.tight_layout()
        pdf.savefig(fig, dpi=dpi)
        plt.close(fig)

    # ---------- build PDF report ----------
    out_pdf.parent.mkdir(parents=True, exist_ok=True)

    with PdfPages(out_pdf) as pdf:
        # Page 1: AUC top sites (global)
        top_n = min(30, len(auc_df))
        top = auc_df.head(top_n).copy()
        labels = (top[protein_col].astype(str) + " " + top[psite_col].astype(str)).tolist()

        fig, ax = plt.subplots(figsize=(11, 0.35 * top_n + 2.5))
        ax.barh(range(top_n)[::-1], top["AUC"].to_numpy()[::-1])
        ax.set_yticks(range(top_n)[::-1])
        ax.set_yticklabels(labels[::-1], fontsize=8)
        ax.set_xlabel("AUC of S over time")
        ax.set_title(f"Top {top_n} sites by total signaling (AUC)")
        ax.grid(True, axis="x", alpha=0.25)
        fig.tight_layout()
        pdf.savefig(fig, dpi=dpi)
        plt.close(fig)

        # Page 2: Early vs Late scatter (global)
        if not el.empty:
            fig, ax = plt.subplots(figsize=(7.5, 6.5))
            x = el["early_S"].to_numpy(dtype=float)
            y = el["late_S"].to_numpy(dtype=float)
            ax.scatter(x, y, s=20, alpha=0.7)
            lo = float(min(np.min(x), np.min(y)))
            hi = float(max(np.max(x), np.max(y)))
            ax.plot([lo, hi], [lo, hi], linestyle="--", linewidth=1)
            ax.set_xlabel(f"Early mean S (t ≤ {early_cut})")
            ax.set_ylabel(f"Late mean S (t ≥ {late_cut})")
            ax.set_title("Early vs Late signaling per site")
            ax.grid(True, alpha=0.25)
            fig.tight_layout()
            pdf.savefig(fig, dpi=dpi)
            plt.close(fig)

        # Per-protein pages
        for prot, sub in df.groupby(protein_col, sort=True):
            if heatmap_per_protein:
                _heatmap_for_protein(pdf, prot, sub)
            _small_multiples_for_protein(pdf, prot, sub)

    return out_pdf


def process_convergence_history(res, output_dir):
    """
    Extract and save optimization convergence history.

    Args:
        res: Pymoo optimization result object with history attribute
        output_dir: Directory path to save outputs

    Returns:
        pd.DataFrame: Convergence history dataframe with columns
                     [n_evals, gen, min_prot_mse, min_rna_mse, min_phos_mse]
    """

    if res.history is None:
        logger.info("[Warning] No optimization history available.")
        return None

    n_evals = []  # Function evaluations
    hist_F = []  # Objective space values

    if res.history is None or len(res.history) == 0:
        logger.info("[Warning] No optimization history found in result object. Skipping convergence plot.")
        return None

    logger.info("[Output] Processing optimization history...")
    for algo in res.history:
        n_evals.append(algo.evaluator.n_eval)
        opt = algo.opt

        # Get the best (min) of each objective in this generation
        # Note: This is an approximation for MOO (ideally use Hypervolume)
        feas = np.where(opt.get("CV") <= 0)[0]
        if len(feas) > 0:
            hist_F.append(np.min(opt.get("F")[feas], axis=0))
        else:
            hist_F.append(np.min(opt.get("F"), axis=0))

    # Save History CSV
    hist_F = np.array(hist_F)
    df_hist = pd.DataFrame(hist_F, columns=["min_prot_mse", "min_rna_mse", "min_phos_mse"])
    df_hist.insert(0, "n_evals", n_evals)
    df_hist["gen"] = np.arange(len(df_hist))
    df_hist.to_csv(os.path.join(output_dir, "convergence_history.csv"), index=False)

    # Plot Convergence
    plt.figure(figsize=(10, 6))
    plt.plot(df_hist["gen"], df_hist["min_prot_mse"], label="Protein MSE")
    plt.plot(df_hist["gen"], df_hist["min_rna_mse"], label="RNA MSE")
    plt.plot(df_hist["gen"], df_hist["min_phos_mse"], label="Phospho MSE")
    plt.yscale("log")
    plt.title("Convergence History (Best Error per Gen)")
    plt.xlabel("Generation")
    plt.ylabel("MSE (Log Scale)")
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.savefig(os.path.join(output_dir, "convergence_plot.png"), dpi=300)
    plt.close()

    logger.info("[Output] Saved convergence history and plot.")

    return df_hist


def export_kinase_activities(sys, idx, output_dir, t_max=120, n_points=121):
    """
    Calculates and saves the effective Kinase Activity (Profile * c_k) over time.
    """
    # Create time grid for plotting
    t_grid = np.linspace(0, t_max, n_points)

    # Raw data profile from the system inputs
    orig_t = sys.kin.grid
    orig_K = sys.kin.Kmat

    activities = []

    for k_idx, k_name in enumerate(idx.kinases):
        # 1. Get base profile from MS data
        base_profile = orig_K[k_idx, :]

        # 2. Interpolate to smooth grid
        interp_func = interp1d(orig_t, base_profile, kind='linear', fill_value="extrapolate")
        smooth_profile = interp_func(t_grid)

        # 3. Apply optimized multiplier c_k
        # c_k is stored in sys.c_k
        multiplier = sys.c_k[k_idx]
        act_trace = smooth_profile * multiplier

        activities.append(act_trace)

    # Build DataFrame
    df_act = pd.DataFrame(np.array(activities).T, columns=idx.kinases)
    df_act.insert(0, "time", t_grid)

    # Save CSV
    save_path = os.path.join(output_dir, "kinase_activities_dynamic.csv")
    df_act.to_csv(save_path, index=False)
    logger.info(f"[Output] Saved dynamic kinase activities to {save_path}")

    # Plot Top 10 Active Kinases
    plt.figure(figsize=(12, 8))

    # Find kinases with highest integral (Area Under Curve)
    auc = df_act.drop("time", axis=1).sum()
    top_k = auc.nlargest(10).index

    for k in top_k:
        plt.plot(df_act["time"], df_act[k], label=k, linewidth=2)

    plt.title("Top 10 Kinase Activities Over Time (Effective)", fontsize=14)
    plt.xlabel("Time (min)", fontsize=12)
    plt.ylabel("Activity (a.u.) = Abundance × c_k", fontsize=12)
    plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "kinase_activities_plot.png"), dpi=100)
    plt.close()


def export_param_correlations(res, slices, idx, output_dir, best_idx=None):
    """
    Plots kinase parameter correlation across Pareto front and gene parameter correlation for best solution.

    Args:
        res: Result object containing optimization results.
        slices: Dictionary of parameter slices.
        idx: Index object containing model indices.
        output_dir: Directory where results will be saved.
        best_idx: Index of the best solution to plot gene parameter correlations.
    """
    X = res.X

    # --- Plot 1: Kinase Parameter Correlation (Pareto Front) ---
    # This shows if kinases are "fighting" each other or identifiable
    kin_slice = slices["c_k"]
    X_kin = X[:, kin_slice]

    if X_kin.shape[1] > 0:
        df_kin = pd.DataFrame(X_kin, columns=idx.kinases)
        corr_kin = df_kin.corr()

        plt.figure(figsize=(14, 12))
        sns.heatmap(
            corr_kin,
            cmap="RdBu_r",
            center=0,
            square=True,
            xticklabels=True,
            yticklabels=True,
            vmin=-1, vmax=1
        )
        plt.title("Correlation of Kinase Parameters (Pareto Set)", fontsize=16)
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, "correlation_kinases_pareto.png"), dpi=300)
        plt.close()
        logger.info("[Output] Saved kinase parameter correlation plot.")

    # --- Plot 2: Gene Parameter Correlation (Population mechanism) ---
    # If best_idx is provided, we analyze that specific solution.
    # Otherwise we analyze the first solution.
    if best_idx is None:
        best_idx = 0

    theta_best = X[best_idx].astype(float)
    p = unpack_params(theta_best, slices)

    # Extract gene params: A_i, B_i, C_i, D_i, E_i
    # Shape: (N_proteins,)
    gene_data = {
        "Synthesis (A)": p["A_i"],
        "RNA Decay (B)": p["B_i"],
        "Translation (C)": p["C_i"],
        "Prot Decay (D)": p["D_i"],
        "Dephos (E)": p["E_i"]
    }

    df_genes = pd.DataFrame(gene_data)

    # Compute correlation across the 206 proteins
    corr_genes = df_genes.corr()

    plt.figure(figsize=(8, 6))
    sns.heatmap(
        corr_genes,
        cmap="viridis",
        annot=True,
        fmt=".2f",
        square=True
    )
    plt.title(f"Mechanistic Coupling (Gene Params, Sol {best_idx})", fontsize=14)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "correlation_gene_params.png"), dpi=300)
    plt.close()

    # Also plot pairplot to see distributions
    sns.pairplot(df_genes, kind="reg", plot_kws={'line_kws': {'color': 'red'}, 'scatter_kws': {'alpha': 0.1}})
    plt.savefig(os.path.join(output_dir, "distribution_gene_params.png"), dpi=300)
    plt.close()

    logger.info("[Output] Saved gene parameter correlation plots.")


def export_residuals(sys, idx, df_prot, df_rna, df_phos, output_dir):
    """
    Calculates and plots residuals (Observed - Predicted) for the best solution.
    Helps identify systematic bias (e.g., 'Always under-predicts at t=10' or 'Always over-predicts at t=100').
    """
    # 1. Get Predictions on data timepoints
    # We need to extract the exact timepoints from the dataframes
    tp_p = df_prot["time"].unique()
    tp_r = df_rna["time"].unique()
    tp_ph = df_phos["time"].unique()

    dfp, dfr, dfph = simulate_and_measure(sys, idx, tp_p, tp_r, tp_ph)

    data_pairs = [
        ("Protein", df_prot, dfp, ["protein", "time"]),
        ("RNA", df_rna, dfr, ["protein", "time"]),
        ("Phospho", df_phos, dfph, ["protein", "psite", "time"])
    ]

    fig, axes = plt.subplots(1, 3, figsize=(18, 5))

    all_residuals = []

    for ax, (name, df_obs, df_pred, merge_cols) in zip(axes, data_pairs):
        if df_obs.empty or df_pred is None:
            continue

        # Merge Obs and Pred
        merged = pd.merge(df_obs, df_pred, on=merge_cols, suffixes=("_obs", "_pred"))

        # Calculate Residuals
        # res = (Pred - Obs)
        merged["residual"] = merged["pred_fc"] - merged["fc"]

        # Plot Residuals vs Time
        sns.scatterplot(data=merged, x="time", y="residual", ax=ax, alpha=0.5)
        ax.axhline(0, color="red", linestyle="--")
        ax.set_title(f"{name} Residuals")
        ax.set_ylabel("Error (Pred - Obs)")

        # Calculate Bias stats
        bias = merged["residual"].mean()
        rmse = np.sqrt((merged["residual"] ** 2).mean())
        ax.text(0.05, 0.9, f"Bias: {bias:.3f}\nRMSE: {rmse:.3f}", transform=ax.transAxes,
                bbox=dict(facecolor='white', alpha=0.8))

        all_residuals.append(merged)

    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "residuals_analysis.png"))
    plt.close()

    # Save raw residuals to CSV
    if all_residuals:
        full_res = pd.concat(all_residuals, ignore_index=True)
        full_res.to_csv(os.path.join(output_dir, "residuals_table.csv"), index=False)
        logger.info("[Output] Saved residual analysis.")


def export_parameter_distributions(res, slices, idx, output_dir):
    """
    Plots boxplots of parameters across the ENTIRE Pareto front.
    Shows which parameters are 'identifiable' (tight box) vs 'sloppy' (wide box).

    Args:
        res: Optimization result object containing Pareto front data.
        slices: Dictionary mapping parameter names to their column indices in res.X.
        idx: Index object containing model-specific information.
        output_dir: Directory where plots will be saved.
    """
    X = res.X

    # --- 1. Kinase Multipliers (c_k) ---
    kin_slice = slices["c_k"]
    X_kin = X[:, kin_slice]

    if X_kin.shape[1] > 0:
        df_kin = pd.DataFrame(X_kin, columns=idx.kinases)

        plt.figure(figsize=(15, 6))
        # Sort by median value for cleaner plot
        sorted_idx = df_kin.median().sort_values(ascending=False).index
        sns.boxplot(data=df_kin[sorted_idx], color="lightblue")
        plt.xticks(rotation=90)
        plt.title("Uncertainty in Kinase Parameters (Pareto Front Distribution)")
        plt.ylabel("Activity Multiplier (c_k)")
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, f"dist_kinases_uncertainty.png"), dpi=300)
        plt.close()

    # --- 2. Global Parameters (tf_scale) ---
    # Check if tf_scale varies
    tf_slice = slices["tf_scale"]
    X_tf = X[:, tf_slice]

    plt.figure(figsize=(6, 5))
    sns.violinplot(data=X_tf, color="lightgreen")
    plt.title("Distribution of Global TF Scale")
    plt.ylabel("tf_scale value")
    plt.savefig(os.path.join(output_dir, "dist_tf_scale.png"), dpi=300)
    plt.close()

    logger.info("[Output] Saved parameter uncertainty distributions.")
